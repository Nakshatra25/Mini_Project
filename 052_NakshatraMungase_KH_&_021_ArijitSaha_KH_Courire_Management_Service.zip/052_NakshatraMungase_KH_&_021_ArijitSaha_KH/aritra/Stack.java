import aritra.MiniProject;
import java.util.Scanner;
class Stack
{
    int top=-1, capacity=5;
    int stack[]=new int[capacity];

  void Push() 
    {
        
        
        System.out.println("enter number");
        Scanner sc=new Scanner(System.in);
        int x=sc.nextInt();
        
        if(top==capacity-1)
            {
                System.out.println("stack overflow");
            }
        else{
                top++;
                stack[top]=x;
            }  
    }
     void Pop()
    {   
         MiniProject s=new  MiniProject();
        
        int item;
        if(top==-1)
        {
            System.out.println("underflow");
        }
        else
        {
            item=stack[top];
            top--;
            System.out.println(stack[top]);
        }
    }
     void Peek() 
    {
         MiniProject s=new  MiniProject();
        if(top==-1)
        {
            System.out.println("no element");
        }
        else
        {
            System.out.println(stack[top]);
        }
    }
     void Display() 
    {
         MiniProject s=new  MiniProject();
        
        for(int i=top;i>=0;i--)
        {
            System.out.println(stack[i]);
        }
    }    

}

