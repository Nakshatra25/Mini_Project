package aritra;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;  
import java.util.*;

public class MiniProject
{   
    
     
     static int count=0;
        
    public static void main(String args[])
    {
        
         Scanner sc= new Scanner(System.in);
       
        
        System.out.println("\n**************************************************************************\n          ARITRA COURIER SERVICE \n***************************************************************************");
        System.out.println("  ##### We think beyond the borders #####");
        
        Scanner sb= new Scanner(System.in);
        System.out.println("*************************************************************************** ");
        System.out.println("\nEnter the Sender's Details");
        System.out.print("Name: ");
        String sname= sb.nextLine();
        System.out.print("Adress: ");
        String sadress= sb.nextLine();
        System.out.print("Contact no: ");
        long cn= sb.nextLong();
         System.out.println("*************************************************************************** ");
        System.out.println("Enter the Reciever's Details");
        System.out.print("Name: ");
        sb.nextLine();
        String rname= sb.nextLine();
        System.out.print("Contact no: ");
        long rcn= sb.nextLong();
       
        
             
       
        City Delhi= new City(100,50,15);
        City Hyderabad=new City(110,50,10);
        City Bangalore=new City(100,50,20);
        City Chennai=new City(130,50,16);
        City Kolkata=new City(150,50,10);
           
       Stack s= new Stack();
          
  
        int choice;
        System.out.println("*************************************************************************** ");
        System.out.println("Choose your Destination City Code");
        System.out.println("1. Delhi");
        System.out.println("2. Hyderabad");
        System.out.println("3. Bangalore");
        System.out.println("4. Chennai");
        System.out.println("5. Kolkata");
        System.out.println("*************************************************************************** ");
        System.out.println("To Show your Bill Press 9");
        System.out.println("To Cancel your previous order Press 0 ");
        System.out.println("To Exit Press 8");
        System.out.println("*************************************************************************** ");
        System.out.print("Enter Choice: ");
      
       while(true){
        choice=sc.nextInt();
        switch(choice)
            
        {
            case 1:   s.Push(Delhi);
                      System.out.println("Order ID: "+Delhi.uniqueid);
                      System.out.println("Total cost: "+Delhi.calculate());
                      System.out.println("*************************************************************************** ");
                      System.out.print("Enter Choice: "); 
                      count++;    
                      break;
                      
            case 2:   s.Push(Hyderabad);
                      System.out.println("Order ID: "+Hyderabad.uniqueid);
                      System.out.println("Total cost: "+Hyderabad.calculate());
                      System.out.println("*************************************************************************** ");
                      System.out.print("Enter Choice: ");
                      count++;
                      break;
                      
            case 3:     s.Push(Bangalore);
                        System.out.println("Order ID: "+Bangalore.uniqueid);
                        System.out.println("Total cost: "+Bangalore.calculate());
                        System.out.println("*************************************************************************** ");
                        System.out.print("Enter Choice: ");
                        count++;
                        break;          
            case 4:     s.Push(Chennai);
                        System.out.println("Order ID: "+Chennai.uniqueid);
                        System.out.println("Total cost: "+Chennai.calculate());
                        System.out.println("*************************************************************************** ");
                        System.out.print("Enter Choice: ");
                        count++;
                      break;
            case 5:   s.Push(Kolkata);
                      System.out.println("Order ID: "+Kolkata.uniqueid);
                      System.out.println("Total cost: "+Kolkata.calculate());
                      System.out.println("*************************************************************************** ");
                      System.out.print("Enter City Code: ");
                      count++;
                      break;
            case 9:  try{
                    s.timeDate();
                    for(int i=0; i<count; i++ )
                    System.out.println("Destination Cost: "+s.stack[i].dcost+" | Weight Cost: "+s.stack[i].wcost+" | Sub total: "+s.stack[i].sT);
                     System.out.println("*************************************************************************** ");
                    System.out.println("          Grand Total : " +s.stack[count-1].gT);
                     System.out.println("*************************************************************************** ");
                         }
                     catch(Exception e){
                         System.out.println(e);
                     }
                     System.out.print("Enter Choice: ");
                       break;
            case 0:  try{
                    s.Pop().popcalculate();
                System.out.println( "Your last order has been cancelled");
                 System.out.println("*************************************************************************** ");
                 count--;
                   }
                  catch(Exception e){
                         System.out.println(e);
                           } 
                        System.out.print("Enter Choice: ");
                          break;
            case 8: return;           
                       
           
            default:
                System.out.println("invalide choice");
        }
       }
        
      }
   
{
     
}
    }

class Stack
{
    int top=-1, capacity=5;
    City stack[]=new City[capacity];

  void Push(City c) 
    {
        
     
        if(top==capacity-1)
            {
                System.out.println("stack overflow");
            }
        else{
                top++;
                stack[top]=c;
            }  
    }
     City Pop()
    {   
         
        
       
        if(top==-1)
        {
            System.out.println("underflow");
        }
      
        
            City item=stack[top];
            System.out.println(stack[top].uniqueid);
            top--;
            return item;
        
    }
         void Display() 
    {
       
        
        for(int i=top;i>=0;i--)
        {
            System.out.println(stack[i]);
        }
    }
         void  timeDate()
	  {
                //  DateTimeFormatter dtf= DateTimeFormatter.ofPattern("yyyy/MM/dd");
		  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	   
		  LocalDateTime now = LocalDateTime.now();

		   System.out.println("Date : "+dtf.format(now));
	  } 

}