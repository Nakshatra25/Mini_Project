package aritra;
import java.util.UUID;

/**
 *
 * @author aritra
 */
public class City {
int dcost, wcost,weight,sT;
static int gT;
String uniqueid;

City(int dcost, int wcost, int weight){
 this.dcost=dcost;
 this.wcost=wcost;
this.uniqueid=UUID.randomUUID().toString();

 this.weight=weight;
 
}
  City(){
      
        }
 int calculate()
 {
          if (weight<=15){
                System.out.println("Weight cost: "+wcost);
                System.out.println("Destination cost: "+dcost);
                sT=wcost+dcost;
                System.out.println("Sub Total: "+(sT));
                gT=gT+sT;
                return gT;
                      } 
            else
            {
               int wdiff=weight-15;
                wcost=wcost+wdiff*10;
                System.out.println("Weight cost: "+wcost);
                System.out.println("Destination cost: "+dcost);
                sT=wcost+dcost;
                System.out.println("Sub Total: "+(sT));
                gT=gT+sT;
                return gT;
            }  
 }
 int popcalculate(){
     gT=gT-(sT);
     return gT;
 }
  
  
}